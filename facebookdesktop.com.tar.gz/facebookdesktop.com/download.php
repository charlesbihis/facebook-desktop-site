<?php

// connect to mysql
$connection = mysql_connect("mysql.facebookdesktop.com", "facebookdesktop", "letmein");

if (!$connection)
{
	die("Cound not connect: "  . mysql_error());
}

// load the database
mysql_select_db("facebookdesktop", $connection);

// get the source and set the filename
$source = $_GET['src'];
$file = './download/FacebookDesktop.air';

if ($source == '')
{
	$source = 'direct';
}

// insert values into the db
$result = mysql_query("INSERT INTO downloads VALUES (null, '" . $source . "', now())");

// display result
if (!$result)
{
	die("Cound not connect: "  . mysql_error());
}

// close the connection
mysql_close($connection);

// finally, feed the file
header('Content-Description: File Transfer');
header('Content-Type: application/vnd.adobe.air-applicationinstaller-package+zip');
header('Content-Length: ' . filesize($file));
header('Content-Disposition: attachment; filename=' . basename($file));

readfile($file);

?>