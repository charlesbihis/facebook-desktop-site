<?php

// connect to mysql
$connection = mysql_connect("mysql.facebookdesktop.com", "admin", "senate1");

if (!$connection)
{
	die("Cound not connect: "  . mysql_error());
}

// load the database
mysql_select_db("facebookdesktop", $connection);

// get information from the test table
$result = mysql_query("SELECT email FROM emails");

// display result
if (!$result)
{
	print "FAIL";
}
else
{
	// print out data in structured XML
	print "<emails>\n";
	while($row = mysql_fetch_object($result))
	{
		print "	<email>" . $row->email. "</email>\n";
	}
	print "</emails>";
}

mysql_close($connection);

?>