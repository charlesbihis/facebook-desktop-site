<?php

// connect to mysql
$connection = mysql_connect("mysql.facebookdesktop.com", "admin", "senate1");

if (!$connection)
{
	die("Cound not connect: "  . mysql_error());
}

// load the database
mysql_select_db("facebookdesktop", $connection);

// get the downloads information
$result = mysql_query("SELECT source, count(*) as downloads FROM downloads GROUP BY source");

// display result
if (!$result)
{
	print "FAIL";
}
else
{
	// print out data in structured XML
	print "<downloads>\n";
	while($row = mysql_fetch_object($result))
	{
		print "	<download>\n" . 
			  "		<source>" . $row->source . "</source>\n" . 
			  "		<count>" . $row->downloads . "</count>\n" . 
			  "	</download>\n";
	}
	print "</downloads>";
}

mysql_close($connection);

?>