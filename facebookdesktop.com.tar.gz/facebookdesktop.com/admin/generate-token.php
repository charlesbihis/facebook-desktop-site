<?php

// generate token
print md5(uniqid(mt_rand(), true));

?>