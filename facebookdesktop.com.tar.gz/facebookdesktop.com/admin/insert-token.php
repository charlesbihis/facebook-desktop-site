<?php

// connect to mysql
$connection = mysql_connect("mysql.facebookdesktop.com", "admin", "senate1");

if (!$connection)
{
	die("Cound not connect: "  . mysql_error());
}

// load the database
mysql_select_db("facebookdesktop", $connection);

// get the token value and description
$value = $_POST["value"];
$description = $_POST["description"];

// insert values into the db
$result = mysql_query("INSERT INTO token VALUES ('" . $value . "', '" . $description . "', 0)");

// display result
if (!$result)
{
	print "FAIL";
}
else
{
	print "SUCCESS";
}

// close the connection
mysql_close($connection);

?>