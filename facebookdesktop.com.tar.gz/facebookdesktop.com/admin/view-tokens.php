<?php

// connect to mysql
$connection = mysql_connect("mysql.facebookdesktop.com", "admin", "senate1");

if (!$connection)
{
	die("Cound not connect: "  . mysql_error());
}

// load the database
mysql_select_db("facebookdesktop", $connection);

// get information from the test table
$result = mysql_query("SELECT value, description, downloads FROM token");

// display result
if (!$result)
{
	print "FAIL";
}
else
{
	// print out data in structured XML
	print "<tokens>\n";
	while($row = mysql_fetch_object($result))
	{
		print "	<token>\n" . 
			  "		<value>" . $row->value."</value>\n" . 
			  "		<description>" . $row->description . "</description>\n" . 
			  "		<downloads>" . $row->downloads . "</downloads>\n" . 
			  "	</token>\n";
	}
	print "</tokens>";
}

mysql_close($connection);

?>